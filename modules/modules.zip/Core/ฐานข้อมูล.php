<?php
/**
 * Core Database Wrapper
 * ตัวจัดการฐานข้อมูลกลาง - ใช้ร่วมกันทุก Module
 */

namespace Modules\Core;

use PDO;
use PDOException;

class ฐานข้อมูล
{
    private static ?ฐานข้อมูล $instance = null;
    private ?PDO $connection = null;
    
    private function __construct()
    {
        $this->เชื่อมต่อ();
    }
    
    /**
     * Singleton Pattern - ใช้ connection เดียวกันทั้งระบบ
     */
    public static function getInstance(): ฐานข้อมูล
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * เชื่อมต่อฐานข้อมูล
     */
    private function เชื่อมต่อ(): void
    {
        // ใช้ config เดิมของระบบ
        require_once __DIR__ . '/../../config/database.php';
        
        try {
            $this->connection = \Database::getInstance()->getConnection();
        } catch (PDOException $e) {
            throw new \Exception("ไม่สามารถเชื่อมต่อฐานข้อมูลได้: " . $e->getMessage());
        }
    }
    
    /**
     * ดึง PDO Connection
     */
    public function getConnection(): PDO
    {
        return $this->connection;
    }
    
    /**
     * Query แบบ Prepared Statement
     */
    public function query(string $sql, array $params = []): \PDOStatement
    {
        $stmt = $this->connection->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
    
    /**
     * ดึงข้อมูลแถวเดียว
     */
    public function fetchOne(string $sql, array $params = []): ?array
    {
        $stmt = $this->query($sql, $params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }
    
    /**
     * ดึงข้อมูลทั้งหมด
     */
    public function fetchAll(string $sql, array $params = []): array
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Insert และ return ID
     */
    public function insert(string $table, array $data): int
    {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        
        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
        $this->query($sql, array_values($data));
        
        return (int) $this->connection->lastInsertId();
    }
    
    /**
     * Update
     */
    public function update(string $table, array $data, string $where, array $whereParams = []): int
    {
        $set = implode(' = ?, ', array_keys($data)) . ' = ?';
        $sql = "UPDATE {$table} SET {$set} WHERE {$where}";
        
        $stmt = $this->query($sql, array_merge(array_values($data), $whereParams));
        return $stmt->rowCount();
    }
}
