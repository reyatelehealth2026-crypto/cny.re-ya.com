<?php
/**
 * Model: การตั้งค่า AI
 * จัดการข้อมูลการตั้งค่า AI Chat ในฐานข้อมูล
 */

namespace Modules\AIChat\Models;

use Modules\Core\ฐานข้อมูล;

class การตั้งค่าAI
{
    private ฐานข้อมูล $db;
    private ?int $lineAccountId;
    private array $settings = [];
    
    // ค่าเริ่มต้น
    private const DEFAULT_SETTINGS = [
        'is_enabled' => false,
        'model' => 'gemini-2.0-flash',
        'temperature' => 0.5,
        'max_tokens' => 300,
        'response_style' => 'friendly',
        'fallback_message' => 'ขออภัยค่ะ ไม่เข้าใจคำถาม กรุณาติดต่อเจ้าหน้าที่',
        'system_prompt' => '',
        'business_info' => '',
        'product_knowledge' => '',
        'sender_name' => '',
        'sender_icon' => '',
        'quick_reply_buttons' => ''
    ];
    
    public function __construct(?int $lineAccountId = null)
    {
        $this->db = ฐานข้อมูล::getInstance();
        $this->lineAccountId = $lineAccountId;
        $this->โหลดการตั้งค่า();
    }
    
    /**
     * โหลดการตั้งค่าจากฐานข้อมูล
     */
    private function โหลดการตั้งค่า(): void
    {
        $this->settings = self::DEFAULT_SETTINGS;
        
        if (!$this->lineAccountId) {
            return;
        }
        
        $result = $this->db->fetchOne(
            "SELECT * FROM ai_chat_settings WHERE line_account_id = ?",
            [$this->lineAccountId]
        );
        
        if ($result) {
            $this->settings = array_merge($this->settings, $result);
        }
    }
    
    /**
     * ตรวจสอบว่า AI เปิดใช้งานหรือไม่
     */
    public function เปิดใช้งานอยู่(): bool
    {
        return (bool) $this->settings['is_enabled'] && !empty($this->settings['gemini_api_key']);
    }
    
    /**
     * ดึง API Key
     */
    public function getApiKey(): string
    {
        return $this->settings['gemini_api_key'] ?? '';
    }
    
    /**
     * ดึง Model ที่ใช้
     */
    public function getModel(): string
    {
        return $this->settings['model'] ?? 'gemini-2.0-flash';
    }
    
    /**
     * ดึง System Prompt
     */
    public function getSystemPrompt(): string
    {
        return $this->settings['system_prompt'] ?? '';
    }
    
    /**
     * ดึง Response Style
     */
    public function getResponseStyle(): string
    {
        return $this->settings['response_style'] ?? 'friendly';
    }
    
    /**
     * ดึงข้อมูลธุรกิจ
     */
    public function getBusinessInfo(): string
    {
        return $this->settings['business_info'] ?? '';
    }
    
    /**
     * ดึงข้อมูลสินค้า
     */
    public function getProductKnowledge(): string
    {
        return $this->settings['product_knowledge'] ?? '';
    }
    
    /**
     * ดึงข้อความ Fallback
     */
    public function getFallbackMessage(): string
    {
        return $this->settings['fallback_message'] ?? self::DEFAULT_SETTINGS['fallback_message'];
    }
    
    /**
     * ดึง Temperature
     */
    public function getTemperature(): float
    {
        return (float) ($this->settings['temperature'] ?? 0.5);
    }
    
    /**
     * ดึง Max Tokens
     */
    public function getMaxTokens(): int
    {
        return (int) ($this->settings['max_tokens'] ?? 300);
    }
    
    /**
     * ดึงชื่อผู้ส่ง
     */
    public function getSenderName(): string
    {
        return $this->settings['sender_name'] ?? '';
    }
    
    /**
     * ดึง Icon ผู้ส่ง
     */
    public function getSenderIcon(): string
    {
        return $this->settings['sender_icon'] ?? '';
    }
    
    /**
     * ดึง Quick Reply Buttons
     */
    public function getQuickReplyButtons(): array
    {
        $buttons = $this->settings['quick_reply_buttons'] ?? '';
        if (empty($buttons)) {
            return [];
        }
        return json_decode($buttons, true) ?: [];
    }
    
    /**
     * ดึงการตั้งค่าทั้งหมด
     */
    public function ทั้งหมด(): array
    {
        return $this->settings;
    }
    
    /**
     * บันทึกการตั้งค่า
     */
    public function บันทึก(array $data): bool
    {
        $data['line_account_id'] = $this->lineAccountId;
        
        $columns = array_keys($data);
        $placeholders = array_map(fn($c) => "?", $columns);
        $updates = array_map(fn($c) => "{$c} = VALUES({$c})", $columns);
        
        $sql = "INSERT INTO ai_chat_settings (" . implode(', ', $columns) . ") 
                VALUES (" . implode(', ', $placeholders) . ")
                ON DUPLICATE KEY UPDATE " . implode(', ', $updates);
        
        $this->db->query($sql, array_values($data));
        $this->โหลดการตั้งค่า();
        
        return true;
    }
}
