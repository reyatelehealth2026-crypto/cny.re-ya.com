<?php
/**
 * AIChat Module Autoloader
 * โหลด Classes อัตโนมัติสำหรับ Module AIChat
 */

spl_autoload_register(function ($class) {
    // ตรวจสอบว่าเป็น class ใน Modules namespace หรือไม่
    if (strpos($class, 'Modules\\') !== 0) {
        return;
    }
    
    // แปลง namespace เป็น path
    // Modules\AIChat\Services\บริการGeminiAPI -> modules/AIChat/Services/บริการGeminiAPI.php
    $relativePath = str_replace('\\', '/', $class);
    $relativePath = str_replace('Modules/', '', $relativePath);
    
    $file = __DIR__ . '/../' . $relativePath . '.php';
    
    if (file_exists($file)) {
        require_once $file;
    }
});

/**
 * Helper function สำหรับโหลด Module
 */
function loadAIChatModule(): void
{
    // โหลด Core ก่อน
    require_once __DIR__ . '/../Core/ฐานข้อมูล.php';
    
    // โหลด Models
    require_once __DIR__ . '/Models/การตั้งค่าAI.php';
    require_once __DIR__ . '/Models/ประวัติการสนทนา.php';
    
    // โหลด Services
    require_once __DIR__ . '/Services/บริการวิเคราะห์บริบท.php';
    require_once __DIR__ . '/Services/บริการสร้างพรอมต์.php';
    require_once __DIR__ . '/Services/บริการGeminiAPI.php';
    require_once __DIR__ . '/Services/บริการจัดการการสนทนา.php';
}
