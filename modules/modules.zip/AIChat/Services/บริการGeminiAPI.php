<?php
/**
 * Service: บริการ Gemini API
 * เชื่อมต่อและเรียกใช้ Google Gemini API
 */

namespace Modules\AIChat\Services;

use Modules\AIChat\Models\การตั้งค่าAI;

class บริการGeminiAPI
{
    private การตั้งค่าAI $settings;
    
    private const API_BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';
    
    public function __construct(การตั้งค่าAI $settings)
    {
        $this->settings = $settings;
    }
    
    /**
     * ส่งข้อความไปยัง Gemini API แบบ Multi-turn Conversation
     * 
     * @param string $systemPrompt System Prompt (คำสั่งและบริบท)
     * @param array $conversationHistory ประวัติการสนทนา
     * @return array ['success' => bool, 'text' => string, 'error' => string]
     */
    public function ส่งข้อความ(string $systemPrompt, array $conversationHistory): array
    {
        $apiKey = $this->settings->getApiKey();
        $model = $this->settings->getModel();
        
        if (empty($apiKey)) {
            return ['success' => false, 'error' => 'ไม่พบ API Key'];
        }
        
        $url = self::API_BASE . $model . ':generateContent?key=' . $apiKey;
        
        // สร้าง contents array สำหรับ multi-turn conversation
        $contents = $this->สร้างContents($systemPrompt, $conversationHistory);
        
        $data = [
            'contents' => $contents,
            'generationConfig' => [
                'temperature' => $this->settings->getTemperature(),
                'maxOutputTokens' => $this->settings->getMaxTokens(),
                'topP' => 0.9,
                'topK' => 20
            ],
            'safetySettings' => $this->getSafetySettings()
        ];
        
        return $this->เรียกAPI($url, $data);
    }
    
    /**
     * สร้าง contents array สำหรับ Gemini API
     */
    private function สร้างContents(string $systemPrompt, array $history): array
    {
        $contents = [];
        
        // System prompt เป็น user message แรก
        $contents[] = [
            'role' => 'user',
            'parts' => [['text' => $systemPrompt]]
        ];
        
        // Model acknowledgment
        $contents[] = [
            'role' => 'model',
            'parts' => [['text' => 'เข้าใจแล้วค่ะ จะทำตามกฎเหล็กทุกข้อ']]
        ];
        
        // เพิ่มประวัติการสนทนา
        foreach ($history as $msg) {
            $role = $msg['role'] === 'user' ? 'user' : 'model';
            $contents[] = [
                'role' => $role,
                'parts' => [['text' => $msg['content']]]
            ];
        }
        
        return $contents;
    }
    
    /**
     * Safety Settings สำหรับ Gemini
     */
    private function getSafetySettings(): array
    {
        return [
            ['category' => 'HARM_CATEGORY_HARASSMENT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],
            ['category' => 'HARM_CATEGORY_HATE_SPEECH', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],
            ['category' => 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],
            ['category' => 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE']
        ];
    }
    
    /**
     * เรียก API ด้วย cURL
     */
    private function เรียกAPI(string $url, array $data): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return ['success' => false, 'error' => 'cURL error: ' . $error];
        }
        
        $result = json_decode($response, true);
        
        if ($httpCode !== 200) {
            $errorMsg = $result['error']['message'] ?? 'HTTP ' . $httpCode;
            return ['success' => false, 'error' => $errorMsg];
        }
        
        $text = $result['candidates'][0]['content']['parts'][0]['text'] ?? null;
        
        if ($text) {
            // Clean up response
            $text = trim($text);
            $text = preg_replace('/^\*\*|\*\*$/m', '', $text);
            
            return ['success' => true, 'text' => $text];
        }
        
        return ['success' => false, 'error' => 'ไม่ได้รับข้อความตอบกลับ'];
    }
    
    /**
     * ทดสอบ API Key
     */
    public function ทดสอบAPIKey(): array
    {
        $apiKey = $this->settings->getApiKey();
        
        if (empty($apiKey)) {
            return ['success' => false, 'error' => 'ไม่พบ API Key'];
        }
        
        $url = self::API_BASE . 'gemini-2.0-flash:generateContent?key=' . $apiKey;
        
        $data = [
            'contents' => [
                ['parts' => [['text' => 'ตอบว่า OK']]]
            ]
        ];
        
        return $this->เรียกAPI($url, $data);
    }
}
