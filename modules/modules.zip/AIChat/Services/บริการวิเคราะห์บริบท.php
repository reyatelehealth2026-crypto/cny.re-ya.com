<?php
/**
 * Service: บริการวิเคราะห์บริบท
 * วิเคราะห์ประวัติการสนทนาเพื่อดึงข้อมูลสำคัญ
 */

namespace Modules\AIChat\Services;

class บริการวิเคราะห์บริบท
{
    // รายการอาการที่รู้จัก
    private const SYMPTOM_PATTERNS = [
        'ปวดหัว', 'ปวดคอ', 'ปวดหลัง', 'ปวดท้อง', 'ปวดตื้อ', 'ปวดตื้อๆ',
        'ไข้', 'ไอ', 'เจ็บคอ', 'คัดจมูก', 'น้ำมูก', 'ท้องเสีย',
        'คลื่นไส้', 'อาเจียน', 'ผื่น', 'คัน', 'ปวดเมื่อย',
        'เวียนหัว', 'อ่อนเพลีย', 'นอนไม่หลับ', 'ปวดกล้ามเนื้อ',
        'หายใจไม่สะดวก', 'หายใจลำบาก', 'แน่นหน้าอก', 
        'ชา', 'มือชา', 'นิ้วชา', 'ปวดต้นคอ', 'ปวดหลังต้นคอ'
    ];
    
    // Pattern สำหรับคำตอบปฏิเสธ
    private const NEGATIVE_PATTERNS = '/^(ไม่มี|ไม่|ไม่มีครับ|ไม่มีค่ะ|ไม่ครับ|ไม่ค่ะ|ไม่มีแล้ว|ไม่แพ้)$/u';
    
    /**
     * วิเคราะห์ประวัติการสนทนาและดึงข้อมูลสำคัญ
     * 
     * @param array $conversationHistory ประวัติการสนทนา
     * @return array ข้อมูลที่ดึงได้ ['อาการ' => '...', 'ระยะเวลา' => '...', ...]
     */
    public function วิเคราะห์(array $conversationHistory): array
    {
        $info = [];
        $fullText = $this->รวมข้อความทั้งหมด($conversationHistory);
        
        // ดึงข้อมูลพื้นฐาน
        $info = array_merge($info, $this->ดึงอายุ($fullText));
        $info = array_merge($info, $this->ดึงน้ำหนัก($fullText));
        $info = array_merge($info, $this->ดึงระยะเวลา($fullText));
        $info = array_merge($info, $this->ดึงอาการ($fullText));
        
        // วิเคราะห์แบบ pair (AI ถาม → ลูกค้าตอบ)
        $info = array_merge($info, $this->วิเคราะห์คู่คำถามคำตอบ($conversationHistory));
        
        // Fallback: ตรวจจับจาก fullText
        $info = array_merge($info, $this->ตรวจจับจากข้อความรวม($fullText, $info));
        
        return $info;
    }
    
    /**
     * ตรวจสอบว่าได้ข้อมูลครบหรือยัง
     * 
     * @param array $info ข้อมูลที่มี
     * @return array ข้อมูลที่ยังขาด
     */
    public function ตรวจสอบข้อมูลที่ขาด(array $info): array
    {
        $required = ['อาการ', 'ระยะเวลา', 'อาการร่วม', 'แพ้ยา', 'โรคประจำตัว'];
        $missing = [];
        
        foreach ($required as $field) {
            if (!isset($info[$field])) {
                $missing[] = $field;
            }
        }
        
        return $missing;
    }
    
    /**
     * รวมข้อความทั้งหมดเป็น string เดียว
     */
    private function รวมข้อความทั้งหมด(array $history): string
    {
        $text = '';
        foreach ($history as $msg) {
            $text .= $msg['content'] . ' ';
        }
        return mb_strtolower($text);
    }
    
    /**
     * ดึงอายุจากข้อความ
     */
    private function ดึงอายุ(string $text): array
    {
        if (preg_match('/อายุ\s*(\d+)|(\d+)\s*ปี|(\d+)ปี/u', $text, $m)) {
            $age = $m[1] ?: ($m[2] ?: $m[3]);
            if ($age > 0 && $age < 150) {
                return ['อายุ' => $age . ' ปี'];
            }
        }
        return [];
    }
    
    /**
     * ดึงน้ำหนักจากข้อความ
     */
    private function ดึงน้ำหนัก(string $text): array
    {
        if (preg_match('/น้ำหนัก\s*(\d+)|หนัก\s*(\d+)|(\d+)\s*กิโล|(\d+)กก/u', $text, $m)) {
            $weight = $m[1] ?: ($m[2] ?: ($m[3] ?: $m[4]));
            if ($weight > 0) {
                return ['น้ำหนัก' => $weight . ' กก.'];
            }
        }
        return [];
    }
    
    /**
     * ดึงระยะเวลาจากข้อความ
     */
    private function ดึงระยะเวลา(string $text): array
    {
        if (preg_match('/(\d+)\s*วัน|(\d+)วัน/u', $text, $m)) {
            $days = $m[1] ?: $m[2];
            if ($days > 0 && $days < 365) {
                return ['ระยะเวลา' => $days . ' วัน'];
            }
        }
        return [];
    }
    
    /**
     * ดึงอาการจากข้อความ
     */
    private function ดึงอาการ(string $text): array
    {
        $symptoms = [];
        foreach (self::SYMPTOM_PATTERNS as $symptom) {
            if (mb_strpos($text, $symptom) !== false) {
                $symptoms[] = $symptom;
            }
        }
        
        if (!empty($symptoms)) {
            return ['อาการ' => implode(', ', array_unique($symptoms))];
        }
        return [];
    }
    
    /**
     * วิเคราะห์แบบ pair (AI ถาม → ลูกค้าตอบ)
     */
    private function วิเคราะห์คู่คำถามคำตอบ(array $history): array
    {
        $info = [];
        $lastAIQuestion = '';
        
        foreach ($history as $msg) {
            $content = mb_strtolower(trim($msg['content']));
            
            if ($msg['role'] === 'assistant') {
                $lastAIQuestion = $content;
            } else {
                // ลูกค้าตอบ - ตรวจสอบว่าตอบปฏิเสธหรือไม่
                $isNegative = preg_match(self::NEGATIVE_PATTERNS, $content);
                
                if ($isNegative && $lastAIQuestion) {
                    // ถ้า AI ถามเรื่องอาการอื่น/อาการร่วม
                    if (preg_match('/อาการ.*อื่น|อาการร่วม|มีอาการอื่น|อาการ.*ไหม/u', $lastAIQuestion)) {
                        $info['อาการร่วม'] = 'ไม่มี';
                    }
                    // ถ้า AI ถามเรื่องแพ้ยา
                    if (preg_match('/แพ้ยา|มีแพ้|แพ้.*ไหม/u', $lastAIQuestion)) {
                        $info['แพ้ยา'] = 'ไม่มี';
                    }
                    // ถ้า AI ถามเรื่องโรคประจำตัว
                    if (preg_match('/โรคประจำตัว|มีโรค|โรค.*ไหม/u', $lastAIQuestion)) {
                        $info['โรคประจำตัว'] = 'ไม่มี';
                    }
                }
            }
        }
        
        return $info;
    }
    
    /**
     * ตรวจจับข้อมูลจากข้อความรวม (Fallback)
     */
    private function ตรวจจับจากข้อความรวม(string $text, array $existingInfo): array
    {
        $info = [];
        
        // แพ้ยา
        if (!isset($existingInfo['แพ้ยา']) && preg_match('/ไม่แพ้|ไม่มี.*แพ้|ไม่เคยแพ้/u', $text)) {
            $info['แพ้ยา'] = 'ไม่มี';
        }
        
        // โรคประจำตัว
        if (!isset($existingInfo['โรคประจำตัว']) && preg_match('/ไม่มี.*โรค|ไม่มีโรคประจำตัว|สุขภาพดี/u', $text)) {
            $info['โรคประจำตัว'] = 'ไม่มี';
        }
        
        // อาการร่วม
        if (isset($existingInfo['อาการ']) && !isset($existingInfo['อาการร่วม'])) {
            $noCount = preg_match_all('/(ไม่มีแล้ว|ไม่มีครับ|ไม่มีค่ะ|ไม่ครับ|ไม่ค่ะ)/u', $text);
            if ($noCount >= 1) {
                $info['อาการร่วม'] = 'ไม่มี';
            }
        }
        
        return $info;
    }
}
