<?php
/**
 * Service: บริการจัดการการสนทนา (Orchestrator)
 * ประสานงานระหว่าง Services ต่างๆ เพื่อสร้างการตอบกลับ AI
 */

namespace Modules\AIChat\Services;

use Modules\AIChat\Models\การตั้งค่าAI;
use Modules\AIChat\Models\ประวัติการสนทนา;

class บริการจัดการการสนทนา
{
    private การตั้งค่าAI $settings;
    private ประวัติการสนทนา $historyModel;
    private บริการวิเคราะห์บริบท $contextAnalyzer;
    private บริการสร้างพรอมต์ $promptBuilder;
    private บริการGeminiAPI $geminiAPI;
    
    public function __construct(int $lineAccountId)
    {
        $this->settings = new การตั้งค่าAI($lineAccountId);
        $this->historyModel = new ประวัติการสนทนา();
        $this->contextAnalyzer = new บริการวิเคราะห์บริบท();
        $this->promptBuilder = new บริการสร้างพรอมต์($this->settings);
        $this->geminiAPI = new บริการGeminiAPI($this->settings);
    }
    
    /**
     * ตรวจสอบว่า AI เปิดใช้งานหรือไม่
     */
    public function เปิดใช้งานอยู่(): bool
    {
        return $this->settings->เปิดใช้งานอยู่();
    }
    
    /**
     * สร้างการตอบกลับสำหรับข้อความของลูกค้า
     * 
     * @param string $userMessage ข้อความจากลูกค้า
     * @param int $userId User ID ในฐานข้อมูล
     * @return array ['success' => bool, 'response' => string, 'message' => array]
     */
    public function สร้างการตอบกลับ(string $userMessage, int $userId): array
    {
        if (!$this->เปิดใช้งานอยู่()) {
            return [
                'success' => false,
                'error' => 'AI ไม่ได้เปิดใช้งาน'
            ];
        }
        
        try {
            // 1. ดึงประวัติการสนทนา
            $history = $this->historyModel->ดึงประวัติล่าสุด($userId, 10);
            
            // 2. เพิ่มข้อความใหม่เข้าไปใน history
            $fullHistory = $history;
            $fullHistory[] = ['role' => 'user', 'content' => $userMessage];
            
            // 3. ดึงข้อมูลลูกค้า
            $customerInfo = $this->historyModel->ดึงข้อมูลลูกค้า($userId);
            
            // 4. สร้าง System Prompt
            $systemPrompt = $this->promptBuilder->สร้าง($fullHistory, $customerInfo);
            
            // 5. เรียก Gemini API
            $result = $this->geminiAPI->ส่งข้อความ($systemPrompt, $fullHistory);
            
            if (!$result['success']) {
                return [
                    'success' => false,
                    'response' => $this->settings->getFallbackMessage(),
                    'error' => $result['error']
                ];
            }
            
            // 6. สร้าง LINE Message พร้อม Sender และ Quick Reply
            $message = $this->สร้างLINEMessage($result['text']);
            
            return [
                'success' => true,
                'response' => $result['text'],
                'message' => $message
            ];
            
        } catch (\Exception $e) {
            error_log("บริการจัดการการสนทนา error: " . $e->getMessage());
            return [
                'success' => false,
                'response' => $this->settings->getFallbackMessage(),
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * สร้าง LINE Message Object พร้อม Sender และ Quick Reply
     */
    private function สร้างLINEMessage(string $text): array
    {
        $message = [
            'type' => 'text',
            'text' => $text
        ];
        
        // เพิ่ม Sender
        $senderName = $this->settings->getSenderName();
        if (!empty($senderName)) {
            $message['sender'] = ['name' => $senderName];
            
            $senderIcon = $this->settings->getSenderIcon();
            if (!empty($senderIcon)) {
                $message['sender']['iconUrl'] = $senderIcon;
            }
        }
        
        // เพิ่ม Quick Reply
        $quickReplyButtons = $this->settings->getQuickReplyButtons();
        if (!empty($quickReplyButtons)) {
            $items = [];
            foreach ($quickReplyButtons as $btn) {
                if (!empty($btn['label']) && !empty($btn['text'])) {
                    $items[] = [
                        'type' => 'action',
                        'action' => [
                            'type' => 'message',
                            'label' => $btn['label'],
                            'text' => $btn['text']
                        ]
                    ];
                }
            }
            
            if (!empty($items)) {
                $message['quickReply'] = ['items' => array_slice($items, 0, 13)];
            }
        }
        
        return $message;
    }
    
    /**
     * ดึงการตั้งค่า
     */
    public function getSettings(): การตั้งค่าAI
    {
        return $this->settings;
    }
    
    /**
     * ทดสอบ API Key
     */
    public function ทดสอบAPIKey(): array
    {
        return $this->geminiAPI->ทดสอบAPIKey();
    }
}
