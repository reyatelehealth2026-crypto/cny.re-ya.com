<?php
/**
 * Service: บริการสร้างพรอมต์
 * สร้าง System Prompt อัจฉริยะสำหรับ AI
 */

namespace Modules\AIChat\Services;

use Modules\AIChat\Models\การตั้งค่าAI;

class บริการสร้างพรอมต์
{
    private การตั้งค่าAI $settings;
    private บริการวิเคราะห์บริบท $contextAnalyzer;
    
    // Prompt Templates ตาม Response Style
    private const STYLE_PROMPTS = [
        'friendly' => 'คุณเป็นผู้ช่วยที่เป็นมิตร ตอบคำถามอย่างสุภาพและกระชับ ใช้ภาษาไทย ลงท้ายด้วย "ค่ะ/ครับ"',
        'professional' => 'คุณเป็นผู้เชี่ยวชาญมืออาชีพ ตอบคำถามอย่างชัดเจน ถูกต้อง และน่าเชื่อถือ',
        'casual' => 'คุณเป็นเพื่อนที่คุยสบายๆ ตอบแบบเป็นกันเอง ใช้ภาษาง่ายๆ',
        'pharmacy_assistant' => 'คุณคือ "ผู้ช่วยเภสัชกรประจำร้านขายยา" ที่เป็นกันเอง ใจดี ห่วงใยลูกค้าเหมือนคนในครอบครัว'
    ];
    
    public function __construct(การตั้งค่าAI $settings)
    {
        $this->settings = $settings;
        $this->contextAnalyzer = new บริการวิเคราะห์บริบท();
    }
    
    /**
     * สร้าง System Prompt สำหรับ AI
     * 
     * @param array $conversationHistory ประวัติการสนทนา
     * @param array|null $customerInfo ข้อมูลลูกค้า
     * @return string System Prompt
     */
    public function สร้าง(array $conversationHistory, ?array $customerInfo = null): string
    {
        $parts = [];
        
        // 1. กฎเหล็ก
        $parts[] = $this->สร้างกฎเหล็ก();
        
        // 2. ข้อมูลที่วิเคราะห์ได้จาก history
        $extractedInfo = $this->contextAnalyzer->วิเคราะห์($conversationHistory);
        if (!empty($extractedInfo)) {
            $parts[] = $this->สร้างส่วนข้อมูลที่รู้แล้ว($extractedInfo);
        }
        
        // 3. บทบาทของ AI
        $parts[] = $this->สร้างส่วนบทบาท();
        
        // 4. ข้อมูลธุรกิจ
        if ($businessInfo = $this->settings->getBusinessInfo()) {
            $parts[] = "ข้อมูลธุรกิจ:\n" . $businessInfo;
        }
        
        // 5. ข้อมูลสินค้า
        if ($productKnowledge = $this->settings->getProductKnowledge()) {
            $parts[] = "ข้อมูลสินค้า/บริการ:\n" . $productKnowledge;
        }
        
        // 6. ข้อมูลลูกค้า (ถ้ามี)
        if ($customerInfo) {
            $parts[] = $this->สร้างส่วนข้อมูลลูกค้า($customerInfo);
        }
        
        // 7. คำสั่งสำหรับการตอบ
        $missingInfo = $this->contextAnalyzer->ตรวจสอบข้อมูลที่ขาด($extractedInfo);
        $parts[] = $this->สร้างคำสั่งการตอบ($missingInfo);
        
        return implode("\n\n", $parts);
    }
    
    /**
     * สร้างส่วนกฎเหล็ก
     */
    private function สร้างกฎเหล็ก(): string
    {
        return "
[กฎเหล็ก - ต้องทำตามทุกข้อ]

1. ตอบสั้นๆ 1-2 ประโยค ห้ามใช้ bullet points หรือตัวเลข
2. ถามทีละคำถามเท่านั้น
3. ห้ามถามข้อมูลที่รู้แล้วซ้ำอีก (ดูข้อมูลด้านล่าง)
4. ถ้าลูกค้าตอบ 'ไม่มี' = เชื่อทันที ข้ามไปถามเรื่องอื่น

[ลำดับการถาม - ถามเฉพาะที่ยังไม่รู้]
อาการ → ระยะเวลา → อาการร่วม → แพ้ยา → โรคประจำตัว → สรุป+แนะนำยา
";
    }
    
    /**
     * สร้างส่วนข้อมูลที่รู้แล้ว
     */
    private function สร้างส่วนข้อมูลที่รู้แล้ว(array $info): string
    {
        $text = "[ข้อมูลที่ลูกค้าบอกไปแล้ว - ห้ามถามซ้ำ!]\n";
        foreach ($info as $key => $value) {
            $text .= "• {$key}: {$value}\n";
        }
        return $text;
    }
    
    /**
     * สร้างส่วนบทบาท
     */
    private function สร้างส่วนบทบาท(): string
    {
        $systemPrompt = $this->settings->getSystemPrompt();
        
        if (empty($systemPrompt)) {
            $style = $this->settings->getResponseStyle();
            $systemPrompt = self::STYLE_PROMPTS[$style] ?? self::STYLE_PROMPTS['friendly'];
        }
        
        return "บทบาทของคุณ:\n" . $systemPrompt;
    }
    
    /**
     * สร้างส่วนข้อมูลลูกค้า
     */
    private function สร้างส่วนข้อมูลลูกค้า(array $info): string
    {
        $text = "ข้อมูลลูกค้าในระบบ:\n";
        
        if (!empty($info['display_name'])) {
            $text .= "- ชื่อ: {$info['display_name']}\n";
        }
        if (!empty($info['medical_conditions'])) {
            $text .= "- โรคประจำตัว: {$info['medical_conditions']}\n";
        }
        if (!empty($info['drug_allergies'])) {
            $text .= "- แพ้ยา: {$info['drug_allergies']}\n";
        }
        if (!empty($info['current_medications'])) {
            $text .= "- ยาที่ใช้อยู่: {$info['current_medications']}\n";
        }
        
        return $text;
    }
    
    /**
     * สร้างคำสั่งการตอบ
     */
    private function สร้างคำสั่งการตอบ(array $missingInfo): string
    {
        if (empty($missingInfo)) {
            return "[คำสั่ง]: ได้ข้อมูลครบแล้ว! สรุปอาการเป็นประโยคเดียว แนะนำยา OTC และบอกว่ารอเภสัชกร";
        }
        
        $nextQuestion = $missingInfo[0];
        return "[คำสั่ง]: ยังขาดข้อมูล: " . implode(', ', $missingInfo) . " - ถามเรื่อง '{$nextQuestion}' เป็นคำถามสั้นๆ 1 ประโยค";
    }
}
