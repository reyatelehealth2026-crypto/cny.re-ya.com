<?php
/**
 * GeminiChat Adapter
 * เชื่อมต่อ Module ใหม่กับระบบเก่า (Backward Compatible)
 * 
 * ใช้แทน classes/GeminiChat.php โดยไม่ต้องแก้ไข webhook.php
 */

namespace Modules\AIChat\Adapters;

// โหลด Module files
require_once __DIR__ . '/../Autoloader.php';
\loadAIChatModule();

use Modules\AIChat\Services\บริการวิเคราะห์บริบท;
use Modules\AIChat\Services\บริการสร้างพรอมต์;
use Modules\AIChat\Services\บริการGeminiAPI;
use Modules\AIChat\Models\การตั้งค่าAI;
use Modules\AIChat\Models\ประวัติการสนทนา;

class GeminiChatAdapter
{
    private การตั้งค่าAI $settings;
    private ประวัติการสนทนา $historyModel;
    private บริการวิเคราะห์บริบท $contextAnalyzer;
    private บริการสร้างพรอมต์ $promptBuilder;
    private บริการGeminiAPI $geminiAPI;
    private $db;
    private ?int $lineAccountId;
    
    public function __construct($db, ?int $lineAccountId = null)
    {
        $this->db = $db;
        $this->lineAccountId = $lineAccountId;
        
        // สร้าง instances
        $this->settings = new การตั้งค่าAI($lineAccountId);
        $this->historyModel = new ประวัติการสนทนา();
        $this->contextAnalyzer = new บริการวิเคราะห์บริบท();
        $this->promptBuilder = new บริการสร้างพรอมต์($this->settings);
        $this->geminiAPI = new บริการGeminiAPI($this->settings);
    }
    
    /**
     * ตรวจสอบว่า AI เปิดใช้งานหรือไม่
     */
    public function isEnabled(): bool
    {
        return $this->settings->เปิดใช้งานอยู่();
    }
    
    /**
     * ดึงประวัติการสนทนา
     */
    public function getConversationHistory(int $userId, int $limit = 10): array
    {
        return $this->historyModel->ดึงประวัติล่าสุด($userId, $limit);
    }
    
    /**
     * สร้างการตอบกลับ (Compatible กับ GeminiChat เก่า)
     */
    public function generateResponse(string $userMessage, ?int $userId = null, array $conversationHistory = []): ?string
    {
        if (!$userId) {
            return null;
        }
        
        $result = $this->generateResponseWithMessage($userMessage, $userId);
        
        if ($result['success']) {
            return $result['response'];
        }
        
        return $this->settings->getFallbackMessage();
    }
    
    /**
     * สร้างการตอบกลับพร้อม LINE Message Object
     */
    public function generateResponseWithMessage(string $userMessage, int $userId): array
    {
        if (!$this->isEnabled()) {
            return [
                'success' => false,
                'error' => 'AI ไม่ได้เปิดใช้งาน'
            ];
        }
        
        try {
            // 1. ดึงประวัติการสนทนา
            $history = $this->historyModel->ดึงประวัติล่าสุด($userId, 10);
            
            // 2. เพิ่มข้อความใหม่เข้าไปใน history
            $fullHistory = $history;
            $fullHistory[] = ['role' => 'user', 'content' => $userMessage];
            
            // 3. ดึงข้อมูลลูกค้า
            $customerInfo = $this->historyModel->ดึงข้อมูลลูกค้า($userId);
            
            // 4. สร้าง System Prompt
            $systemPrompt = $this->promptBuilder->สร้าง($fullHistory, $customerInfo);
            
            // 5. เรียก Gemini API
            $result = $this->geminiAPI->ส่งข้อความ($systemPrompt, $fullHistory);
            
            if (!$result['success']) {
                return [
                    'success' => false,
                    'response' => $this->settings->getFallbackMessage(),
                    'error' => $result['error']
                ];
            }
            
            // 6. สร้าง LINE Message พร้อม Sender และ Quick Reply
            $message = $this->buildLINEMessage($result['text']);
            
            return [
                'success' => true,
                'response' => $result['text'],
                'message' => $message
            ];
            
        } catch (\Exception $e) {
            error_log("GeminiChatAdapter error: " . $e->getMessage());
            return [
                'success' => false,
                'response' => $this->settings->getFallbackMessage(),
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * สร้าง LINE Message Object พร้อม Sender และ Quick Reply
     */
    private function buildLINEMessage(string $text): array
    {
        $message = [
            'type' => 'text',
            'text' => $text
        ];
        
        // เพิ่ม Sender
        $senderName = $this->settings->getSenderName();
        if (!empty($senderName)) {
            $message['sender'] = ['name' => $senderName];
            
            $senderIcon = $this->settings->getSenderIcon();
            if (!empty($senderIcon)) {
                $message['sender']['iconUrl'] = $senderIcon;
            }
        }
        
        // เพิ่ม Quick Reply
        $quickReplyButtons = $this->settings->getQuickReplyButtons();
        if (!empty($quickReplyButtons)) {
            $items = [];
            foreach ($quickReplyButtons as $btn) {
                if (!empty($btn['label']) && !empty($btn['text'])) {
                    $items[] = [
                        'type' => 'action',
                        'action' => [
                            'type' => 'message',
                            'label' => $btn['label'],
                            'text' => $btn['text']
                        ]
                    ];
                }
            }
            
            if (!empty($items)) {
                $message['quickReply'] = ['items' => array_slice($items, 0, 13)];
            }
        }
        
        return $message;
    }
    
    /**
     * ดึงข้อมูลสุขภาพลูกค้า
     */
    public function getUserMedicalInfo(int $userId): ?array
    {
        return $this->historyModel->ดึงข้อมูลลูกค้า($userId);
    }
    
    /**
     * ทดสอบ API Key
     */
    public function testApiKey(): array
    {
        return $this->geminiAPI->ทดสอบAPIKey();
    }
}
